<?php
	$site_name='Sico';
	$db_host='localhost';
	$db_name='sico';//nombre de la base de datos
	$db_user='root';
	$db_pass='';
?>